using UnityEngine;
using UnityEngine.SceneManagement;

public class GameEntryScene : Scenes
{
    public override void NextScene()
    {
        SceneManager.LoadScene("Guide");
    }
}
