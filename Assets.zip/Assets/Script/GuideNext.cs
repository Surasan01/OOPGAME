using UnityEngine.SceneManagement;
using UnityEngine;
using System;
public class GuideNext : Scenes
{
    public override void NextScene()
    {
        SceneManager.LoadScene("SampleScene");
    }
}
