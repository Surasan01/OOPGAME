using TMPro;
using UnityEngine;

public class GameLogic : GameElement
{
    public Dice dice; // Reference to Dice class
    public TMP_Text TimeMonth;
    public DisplayPlayerInfoStartGame displayPlayerInfoStartGame;
    public StockPriceUpdater stockPriceUpdater;
    public TMP_Text[] stockPriceTexts;
    public StockMarketSimulator stockMarketSimulator;

    void Start()
    {
        InitializeElement();
    }

    public override void InitializeElement()
    {
        displayPlayerInfoStartGame = FindObjectOfType<DisplayPlayerInfoStartGame>();
        dice.OnDiceRolled += OnDiceRolled;
    }

    private void OnDiceRolled(int diceValue)
    {
        int result = displayPlayerInfoStartGame.GetMonthsPerPoint() * diceValue;
        PlayerPrefs.SetInt("TimeMonth", result);
        Debug.Log("Player moves " + displayPlayerInfoStartGame.GetMonthsPerPoint() * diceValue + " months");
        TimeMonth.text = result.ToString() + " เดือน";

        // Update stock prices
        stockPriceUpdater.StartUpdatingStockPrices(result);
    }


    private void OnDestroy()
    {
        // Unsubscribe from the event to avoid memory leaks
        if (dice != null)
        {
            dice.OnDiceRolled -= OnDiceRolled;
        }
    }
}
