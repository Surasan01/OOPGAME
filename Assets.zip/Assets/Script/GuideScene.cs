using UnityEngine;
using System;
using UnityEngine.UI;

public class GuideScene : MonoBehaviour
{
    public Button ButtonSampleScene;

    public GuideNext guideNext;

    void Start()
    {
        GuideNext guideNext = new GuideNext();
        ButtonSampleScene.onClick.AddListener(() => guideNext.NextScene());
    }
}
