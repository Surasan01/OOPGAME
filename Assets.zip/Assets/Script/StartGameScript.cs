using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

public class StartGameScript : MonoBehaviour
{
    public void StartGame()
    {
        StartCoroutine(SendStartGameRequest());
    }

    private IEnumerator SendStartGameRequest()
    {
        UnityWebRequest request = UnityWebRequest.Post("http://localhost:8080/api/startGame", "");
        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("เริ่มเกมเรียบร้อยแล้ว: " + request.downloadHandler.text);
        }
        else
        {
            Debug.LogError("เกิดข้อผิดพลาด: " + request.error);
        }
    }
}
