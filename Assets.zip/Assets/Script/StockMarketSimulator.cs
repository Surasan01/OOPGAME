using System.Collections.Generic;
using UnityEngine;
using System.Linq;

// คลาสสำหรับเก็บข้อมูลการลงทุนในแต่ละหุ้น
[System.Serializable]
public class StockInvestment
{
    public string sector;
    public float shares;              // จำนวนหุ้นที่ถือ
    public float avgBuyPrice;       // ราคาเฉลี่ยที่ซื้อ
    public float totalInvestment;   // เงินลงทุนรวม
    public List<StockTransaction> transactions = new List<StockTransaction>();

    public StockInvestment(string sector)
    {
        this.sector = sector;
        this.shares = 0;
        this.avgBuyPrice = 0;
        this.totalInvestment = 0;
    }
}

// คลาสสำหรับเก็บประวัติการซื้อขาย
[System.Serializable]
public class StockTransaction
{
    public string sector;
    public string type;        // "BUY" หรือ "SELL"
    public int shares;
    public float price;
    public float total;
    public string date;        // เดือนที่ทำรายการ

    public StockTransaction(string sector, string type, int shares, float price, string date)
    {
        this.sector = sector;
        this.type = type;
        this.shares = shares;
        this.price = price;
        this.total = shares * price;
        this.date = date;
    }
}

public class StockMarketSimulator : SetAndUpdate
{
    public TMPro.TMP_Text TechnologyPriceText;
    public TMPro.TMP_Text HealthcarePriceText;
    public TMPro.TMP_Text FinancialsPriceText;
    public TMPro.TMP_Text ConsumerElectronicsPriceText;
    public TMPro.TMP_Text EnergyPriceText;
    public TMPro.TMP_Text EntertainmentPriceText;

    public Dictionary<string, float> stockPrices = new Dictionary<string, float>();
    public Dictionary<string, StockInvestment> investments = new Dictionary<string, StockInvestment>();
    public Dictionary<string, List<Vector2>> volatilitySets = new Dictionary<string, List<Vector2>>();
    public Dictionary<string, string> sectorToVolatilityMap = new Dictionary<string, string>();

    private static Dictionary<string, List<float>> historicalPrices = new Dictionary<string, List<float>>();
    public static int currentMonth = 0;

    private float initialInvestment = 0;
    public float totalValue { get; private set; }
    public float totalReturn { get; private set; }
    public float annualizedReturn { get; private set; }
    public float monthlyReturn { get; private set; }

    void Start()
    {
        InitializeData();
        InitializeStockPrices();
        InitializeVolatilitySets();
        AssignUniqueVolatilitySets();
    }

    private void InitializeData()
    {
        string[] sectors = { "Technology", "Healthcare", "Financials", "Consumer Electronics", "Energy", "Entertainment" };

        foreach (string sector in sectors)
        {
            investments[sector] = new StockInvestment(sector);
            historicalPrices[sector] = new List<float>();
        }
    }

    private void InitializeStockPrices()
    {
        stockPrices["Technology"] = Random.Range(180f, 220f);
        stockPrices["Healthcare"] = Random.Range(30f, 50f);
        stockPrices["Financials"] = Random.Range(80f, 100f);
        stockPrices["Consumer Electronics"] = Random.Range(150f, 180f);
        stockPrices["Energy"] = Random.Range(70f, 90f);
        stockPrices["Entertainment"] = Random.Range(60f, 100f);

        foreach (var pair in stockPrices)
        {
            historicalPrices[pair.Key].Add(pair.Value);
        }

        UpdatePriceTexts();
    }

    private void InitializeVolatilitySets()
    {
        volatilitySets["HighVolatility"] = new List<Vector2> {
            new Vector2(-2.5f, 4), new Vector2(-1.5f, 5), new Vector2(-3, 3.5f), new Vector2(-2, 4.5f)
        };
        volatilitySets["SteadyGrowth"] = new List<Vector2> {
            new Vector2(0.25f, 1), new Vector2(0.5f, 1.5f), new Vector2(0.25f, 0.75f), new Vector2(0.5f, 1.25f)
        };
        volatilitySets["CrisisVolatility"] = new List<Vector2> {
            new Vector2(-5, 1), new Vector2(-7.5f, 2.5f), new Vector2(-6, 2), new Vector2(-10, 1.5f)
        };
        volatilitySets["GrowthWithFluctuation"] = new List<Vector2> {
            new Vector2(-0.5f, 1.5f), new Vector2(-1.5f, 2), new Vector2(0, 1), new Vector2(0.5f, 2)
        };
        volatilitySets["Stable"] = new List<Vector2> {
            new Vector2(-0.25f, 0.25f), new Vector2(-0.3f, 0.7f), new Vector2(-0.2f, 0.8f), new Vector2(-0.1f, 0.6f)
        };
        volatilitySets["MixedVolatility"] = new List<Vector2> {
            new Vector2(-1.5f, 2.5f), new Vector2(-1, 2), new Vector2(-2, 3), new Vector2(-0.5f, 1.5f)
        };
    }

    private void AssignUniqueVolatilitySets()
    {
        List<string> sectors = new List<string> { "Technology", "Healthcare", "Financials", "Consumer Electronics", "Energy", "Entertainment" };
        var shuffledVolatilitySets = volatilitySets.Keys.OrderBy(x => Random.value).ToList();

        for (int i = 0; i < sectors.Count; i++)
        {
            sectorToVolatilityMap[sectors[i]] = shuffledVolatilitySets[i];
            Debug.Log($"Sector: {sectors[i]} assigned to {shuffledVolatilitySets[i]}");
        }
    }

    public void UpdateMonthlyStockPrices()
    {
        currentMonth++;
        float previousTotalValue = CalculateTotalValue();
        Dictionary<string, float> updatedPrices = new Dictionary<string, float>();

        foreach (var pair in stockPrices)
        {
            string sector = pair.Key;
            float currentPrice = pair.Value;
            string volatilitySetName = sectorToVolatilityMap[sector];
            List<Vector2> volatilitySet = volatilitySets[volatilitySetName];
            Vector2 range = volatilitySet[Random.Range(0, volatilitySet.Count)];
            float priceChangePercent = Random.Range(range.x, range.y);
            float newPrice = currentPrice * (1 + priceChangePercent / 100);
            updatedPrices[sector] = newPrice;
            historicalPrices[sector].Add(newPrice);
        }

        stockPrices = updatedPrices;
        UpdatePriceTexts();
        UpdateInvestmentText();
        float newTotalValue = CalculateTotalValue();
        SetmonthlyReturn((newTotalValue - previousTotalValue) / previousTotalValue * 100f);
    }

    public override void UpdateInvestmentText()
    {
        totalValue = CalculateTotalValue();
        if (initialInvestment > 0)
        {
            totalReturn = (totalValue - initialInvestment) / initialInvestment * 100f;
            annualizedReturn = (currentMonth >= 12) ? (Mathf.Pow(1 + totalReturn / 100f, 12f / currentMonth) - 1) * 100f : totalReturn * (12f / currentMonth); // คำนวณ Annualized Return
        }
    }

    public float CalculateTotalValue()
    {
        return investments.Sum(inv => inv.Value.shares * stockPrices[inv.Key]);
    }

    public float GetCurrentPrice(string sector) => stockPrices[sector];
    public List<float> GetPriceHistory(string sector) => historicalPrices[sector];
    public StockInvestment GetInvestment(string sector) => investments[sector];
    public float GetTotalInvestment() => initialInvestment;
    public List<StockTransaction> GetAllTransactions() => investments.Values.SelectMany(inv => inv.transactions).OrderBy(t => t.date).ToList();

    public override void UpdatePriceTexts()
    {
        TechnologyPriceText.text = $"${stockPrices["Technology"]:F2}";
        HealthcarePriceText.text = $"${stockPrices["Healthcare"]:F2}";
        FinancialsPriceText.text = $"${stockPrices["Financials"]:F2}";
        ConsumerElectronicsPriceText.text = $"${stockPrices["Consumer Electronics"]:F2}";
        EnergyPriceText.text = $"${stockPrices["Energy"]:F2}";
        EntertainmentPriceText.text = $"${stockPrices["Entertainment"]:F2}";
    }

    void OnDestroy()
    {
        stockPrices.Clear();
        investments.Clear();
        volatilitySets.Clear();
        sectorToVolatilityMap.Clear();
        historicalPrices.Clear();
        currentMonth = 0;
        initialInvestment = 0;
        totalValue = 0;
        totalReturn = 0;
        annualizedReturn = 0;
        monthlyReturn = 0;
        StockPriceUpdater.AllCashandInvestmentHistory.Clear();
    }

    public float GetmonthlyReturn()
    {
        return monthlyReturn;
    }

    public void SetmonthlyReturn(float value)
    {
        monthlyReturn = value;
    }

    public float GetinitialInvestment()
    {
        return initialInvestment;
    }

    public void SetinitialInvestment(float value)
    {
        initialInvestment = value;
    }
}
