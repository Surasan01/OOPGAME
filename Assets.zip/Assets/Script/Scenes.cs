using UnityEngine;

public class Scenes : MonoBehaviour
{
    public virtual void NextScene()
    {
        // คือการโหลดฉากที่ถัดไป
        UnityEngine.SceneManagement.SceneManager.LoadScene("Next");
    }
}
