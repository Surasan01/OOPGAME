using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StockPriceUpdater : SetAndUpdate
{
    public StockMarketSimulator stockMarketSimulator;
    public TMP_Text[] stockPriceTexts;
    public Window_Graph windowGraph;

    public PlayerPortfolio playerPortfolio;
    public DisplayPlayerInfoStartGame displayPlayerInfoStartGame;

    private Dictionary<string, float> stockPrices;
    private Dictionary<string, List<Vector2>> volatilitySets;
    private Dictionary<string, string> sectorToVolatilityMap;
    private List<Dictionary<string, float>> historicalPrices;


    public Button technologyButton;
    public Button healthcareButton;
    public Button financialsButton;
    public Button consumerElectronicsButton;
    public Button energyButton;
    public Button entertainmentButton;
    public Button growthButton;

    private string currentDisplayedSector = null;

    // เอาไว้เก็บราคาก่อนหน้า
    private Dictionary<string, float> previousStockPrices = new Dictionary<string, float>();

    public TMP_Text AllInvestmentText;
    public TMP_Text ReceivedRoundText;
    public TMP_Text ReturnYearText;
    public TMP_Text PercentOfTotalText;
    public TMP_Text TotalReturnsText; // แสดงรายได้รวมทั้งหมด จาก เงินลงทุนทั้งหมด - เงินต้นที่ซื้อไป

    public static float AllInvestment; // ราคาลงทุนทั้งหมด
    public static List<float> AllCashandInvestmentHistory = new List<float>(); // รายการเก็บราคาลงทุนทั้งหมด กับ ราคาเงินสดทั้งหมด
    public static float round; // รายได้รวมทั้งหมด
    public static float totalReturn; // รายได้รวมทั้งหมด
    public static float percentOfTotal; // ร้อยละของรายได้ทั้งหมด
    public static float ReturnYear; // รายได้รวมต่อปี

    public TMP_InputField Salary; // ใช้ระบุเงินเดือนที่ได้รับ
    public TMP_InputField MoneyofMonth; // ใช้ระบุจำนวนเงินที่ต้องการลงทุนต่อเดือน
    public TMP_Text cashText; // แสดงยอดเงินสดที่มีอยู่

    private float salary; // เงินเดือนที่ได้รับ

    public CharacterLoopMovement characterMovement; // เพิ่มตัวแปรสำหรับ CharacterLoopMovement
    public int currentMonth = 0; // จำนวนเดือนที่ต้องการอัปเดต
    private int endMonth; // จำนวนเดือนสุดท้ายที่ต้องการอัปเดต

    private int age;
    private int endAge;

    void Start()
    {
        age = GameData.GetAge();
        endAge = GameData.GetEndAge();

        endMonth = (endAge - age) *12;  // คำนวณจำนวนเดือนทั้งหมดที่ต้องการอัปเดต

        technologyButton.onClick.AddListener(() => OnButtonClicked("Technology"));
        healthcareButton.onClick.AddListener(() => OnButtonClicked("Healthcare"));
        financialsButton.onClick.AddListener(() => OnButtonClicked("Financials"));
        consumerElectronicsButton.onClick.AddListener(() => OnButtonClicked("Consumer Electronics"));
        energyButton.onClick.AddListener(() => OnButtonClicked("Energy"));
        entertainmentButton.onClick.AddListener(() => OnButtonClicked("Entertainment"));
        growthButton.onClick.AddListener(() =>
        {
            currentDisplayedSector = "Growth";
            DisplayGraphForTotalInvestment();
        });
        growthButton.onClick.AddListener(() => DisplayGraphForTotalInvestment());

        if (stockMarketSimulator == null)
        {
            Debug.LogError("StockMarketSimulator reference is missing!");
            return;
        }

        InitializeData();
    }

    private void InitializeData()
    {
        // Initialize collections
        stockPrices = new Dictionary<string, float>(stockMarketSimulator.stockPrices);
        historicalPrices = new List<Dictionary<string, float>>();

        // Store initial prices in history
        historicalPrices.Add(new Dictionary<string, float>(stockPrices));
    }

    public void StartUpdatingStockPrices(int months)
    {
        StartCoroutine(UpdateStockPricesOverMonths(months));
    }

    private IEnumerator UpdateStockPricesOverMonths(int months)
    {
        //Debug.Log($"Updating stock prices over {months} months...");
        // เริ่มการเคลื่อนที่ของตัวละครหรือตัวบ่งชี้อายุ
        characterMovement.StartCharacterMovement();
        characterMovement.StartAgeIndicatorMovement();

        for (int month = 0; month < months; month++)
        {
            currentMonth++;

            // ตรวจสอบว่าเดือนปัจจุบันมีค่ามากกว่าเดือนสุดท้ายหรือไม่
            if (currentMonth > endMonth)
            {
                SceneManager.LoadScene("EndScene"); // ถ้ามากกว่าให้เปลี่ยนไปหน้าจอสรุปผล
                break;
            }

            // ตรวจสอบว่า stockMarketSimulator อ้างอิงถูกต้อง
            if (stockMarketSimulator == null)
            {
                Debug.LogError("StockMarketSimulator reference is missing!");
                yield break;
            }

            // Call the simulator's monthly update
            stockMarketSimulator.UpdateMonthlyStockPrices();

            // Update local stock prices and add to history
            stockPrices = new Dictionary<string, float>(stockMarketSimulator.stockPrices);
            historicalPrices.Add(new Dictionary<string, float>(stockPrices));


            if (Salary.text != "")
            {
                salary = float.Parse(Salary.text);
            }
            else
            {
                salary = 0;
            }
            PlayerPortfolio.cash += salary;
            Debug.Log(PlayerPortfolio.cash);

            cashText.text = $"{PlayerPortfolio.cash:F2}";
            AutoBuy(); // ซื้อหุ้นโดยอัตโนมัติ

            // Update UI texts
            UpdatePriceTexts();

            // ตรวจสอบว่ามีหุ้นประเภทไหนกำลังแสดงอยู่
            if (!string.IsNullOrEmpty(currentDisplayedSector))
            {
                if (currentDisplayedSector == "Growth")
                {
                    DisplayGraphForTotalInvestment();
                }
                else
                {
                    DisplayGraphForSector(currentDisplayedSector);
                }
            }

            UpdateInvestmentText();

            yield return new WaitForSeconds(1f); // สามารถตั้งเป็น dynamic ได้หากต้องการ
        }

        // หยุดการเคลื่อนที่เมื่อสิ้นสุดการอัปเดต
        characterMovement.StopCharacterMovement();
        characterMovement.StopAgeIndicatorMovement();
    }

    public override void UpdatePriceTexts()
    {
        if (stockPriceTexts.Length < 6)
        {
            Debug.LogError("Not enough text components assigned!");
            return;
        }

        var sectors = new string[]
        {
        "Technology",
        "Healthcare",
        "Financials",
        "Consumer Electronics",
        "Energy",
        "Entertainment"
        };

        for (int i = 0; i < sectors.Length; i++)
        {
            if (stockPriceTexts[i] != null && stockPrices.ContainsKey(sectors[i]))
            {
                float currentPrice = stockPrices[sectors[i]];
                stockPriceTexts[i].text = $"{stockPrices[sectors[i]]:F2}";
                Debug.Log($"{sectors[i]}: {stockPriceTexts[i].text}");

                // เปรียบเทียบราคาปัจจุบันกับราคาก่อนหน้าและเปลี่ยนสีข้อความ
                if (previousStockPrices.ContainsKey(sectors[i]))
                {
                    float previousPrice = previousStockPrices[sectors[i]];
                    if (currentPrice > previousPrice)
                    {
                        stockPriceTexts[i].color = Color.green;
                    }
                    else if (currentPrice < previousPrice)
                    {
                        stockPriceTexts[i].color = Color.red;
                    }
                    else
                    {
                        stockPriceTexts[i].color = Color.white;
                    }
                }

                // อัพเดทราคาก่อนหน้า
                previousStockPrices[sectors[i]] = currentPrice; // อัพเดทราคาก่อนหน้า
            }
            else if (stockPriceTexts[i] != null)
            {
                stockPriceTexts[i].text = "N/A"; // แสดงค่าเป็น N/A ถ้าไม่มีข้อมูล
                Debug.LogWarning($"{sectors[i]} price data is missing.");
            }
        }
    }


    public void DisplayGraphForSector(string sector)
    {
        playerPortfolio.SetCurrentSector(sector);

        if (windowGraph == null)
        {
            Debug.LogError("Window_Graph reference is missing!");
            return;
        }

        // Clear previous graph data
        windowGraph.ClearGraph();

        List<float> sectorPrices = GetHistoricalPricesForSector(sector);
        if (sectorPrices.Count > 0)
        {
            List<int> intPrices = sectorPrices.ConvertAll(price => (int)price); // Convert to int for compatibility
            windowGraph.ShowGraph(intPrices, maxVisibleValueAmount: intPrices.Count,
                getAxisLabelX: (i) => $"{i + 1}", getAxisLabelY: (price) => $"{price}");
        }
    }

    private void UpdateGraphData(int month)
    {
        if (windowGraph == null)
        {
            Debug.LogError("Window_Graph reference is missing!");
            return;
        }

        foreach (var sector in stockPrices.Keys)
        {
            List<float> sectorPrices = GetHistoricalPricesForSector(sector);
            if (sectorPrices.Count > 0)
            {
                List<int> intPrices = sectorPrices.ConvertAll(price => (int)price);
                windowGraph.UpdateGraphData(intPrices);
            }
        }
    }

    public override void UpdateInvestmentText()
    {
        AllInvestment = 0;

        foreach (var investment in stockMarketSimulator.investments)
        {
            string sector = investment.Key;
            StockInvestment stockInvestment = investment.Value;
            Debug.Log($"{sector}: {stockInvestment.shares} shares");

            // ดึงราคาหุ้นปัจจุบันของ Sector นั้นๆ
            float currentPrice = stockMarketSimulator.GetCurrentPrice(sector);

            // คูณราคาปัจจุบันกับจำนวนหุ้นที่ถือใน Sector นี้
            float sectorInvestment = currentPrice * stockInvestment.shares;

            // นำผลลัพธ์มาบวกกับการลงทุนทั้งหมด
            AllInvestment += sectorInvestment;
        }

        AllCashandInvestmentHistory.Add(AllInvestment);

        if (AllInvestment > 0)
        {
            AllInvestmentText.text = $"{AllInvestment:F2}";
        }
        else
        {
            AllInvestmentText.text = "0.00";
        }

        if (AllCashandInvestmentHistory.Count > 1) // ถ้ามีข้อมูลลงทุนมากกว่า 1 รายการ ให้ทำการคำนวณ
        {
            float lastInvestment = AllCashandInvestmentHistory[AllCashandInvestmentHistory.Count - 2]; // ราคาลงทุนก่อนหน้า
            float currentInvestment = AllCashandInvestmentHistory[AllCashandInvestmentHistory.Count - 1]; // ราคาลงทุนปัจจุบัน
            round = currentInvestment - lastInvestment;
            ReceivedRoundText.text = $"{round:F2}";

            totalReturn = AllInvestment - playerPortfolio.Getprinciple();
            TotalReturnsText.text = $"{totalReturn:F2}";
        }

        if (playerPortfolio.Getprinciple() > 0)
        {
            percentOfTotal = ((AllInvestment / playerPortfolio.Getprinciple()) * 100) - 100;
            PercentOfTotalText.text = $"{percentOfTotal:F2}%";
            Debug.Log("AllInvestmentAllInvestmentAllInvestmentAllInvestmentAllInvestmentAllInvestment: " + AllInvestment);
            Debug.Log("percentOfTotal: " + percentOfTotal + "playerPortfolio.Getprinciple()" + playerPortfolio.Getprinciple());
        }
        else
        {
            PercentOfTotalText.text = "0.00%";
        }


        if (AllCashandInvestmentHistory.Count >= 12)
        {
            // คำนวณหาเดือนในปีปัจจุบัน
            int currentMonthInYear = AllCashandInvestmentHistory.Count % 12;

            // หาก currentMonthInYear เป็น 0 แสดงว่าเรามีครบ 12 เดือนพอดี ให้ดึงข้อมูลจากต้นปีปัจจุบัน (ย้อนกลับไป 12 เดือน)
            int monthsInYear = currentMonthInYear == 0 ? 12 : currentMonthInYear;

            // ดึงมูลค่าการลงทุน ณ ต้นปี (นับจากเดือนแรกของปีนี้)
            float investmentAtStartOfYear = AllCashandInvestmentHistory[AllCashandInvestmentHistory.Count - monthsInYear];

            // คำนวณผลตอบแทน % ของปีนั้น
            ReturnYear = ((AllInvestment - investmentAtStartOfYear) / investmentAtStartOfYear) * 100;
            ReturnYearText.text = $"{ReturnYear:F2}%";
        }
        else if (AllCashandInvestmentHistory.Count >= 0 && AllCashandInvestmentHistory.Count <12)
        {
            // คำนวณผลตอบแทน % ของปีนั้น
            ReturnYear = ((AllInvestment / playerPortfolio.Getprinciple()) * 100) - 100;
            ReturnYearText.text = $"{ReturnYear:F2}%";
        }
        else
        {
            ReturnYearText.text = "0.00%";
        }
    }

    private void AutoBuy()
    {
        float monthlyInvestment = 0;
        if (MoneyofMonth.text != "")
        {
            monthlyInvestment = float.Parse(MoneyofMonth.text);
        }

        // คำนวณสัดส่วนการลงทุนจากพอร์ตปัจจุบัน
        Dictionary<string, float> currentInvestments = new Dictionary<string, float>();
        float totalInvestment = 0;

        // คำนวณยอดรวมการลงทุนทั้งหมดและยอดแต่ละ sector
        foreach (var investment in stockMarketSimulator.investments)
        {
            float sectorInvestment = investment.Value.totalInvestment;
            currentInvestments[investment.Key] = sectorInvestment;
            totalInvestment += sectorInvestment;
        }

        float remainingInvestment = monthlyInvestment;

        if (totalInvestment > 0) // ถ้ามีการลงทุนอยู่แล้ว
        {
            float allstart = 0;
            foreach (var investment in currentInvestments)
            {
                string sector = investment.Key;
                allstart += PlayerPortfolio.Setprinciple[sector];
            }

            foreach (var investment in currentInvestments)
            {
                string sector = investment.Key;
                float percentage = (PlayerPortfolio.Setprinciple[sector] / allstart) * 100;
                float amountToInvest = monthlyInvestment * (percentage / 100); // คำนวณจำนวนเงินที่จะลงทุนในแต่ละ sector

                if (amountToInvest > 0)
                {
                    float currentPrice = stockMarketSimulator.GetCurrentPrice(sector);
                    if (currentPrice > 0)
                    {
                        float sharesBought = AutoBuyCurrentStock(sector, amountToInvest);
                        Debug.Log($"Bought {sharesBought} shares of {sector} at {currentPrice} each");
                        remainingInvestment -= sharesBought * currentPrice;
                    } 
                }
            }

        }
        playerPortfolio.UpdateCashUI();
        playerPortfolio.UpdatePortfolioUI();
    }

    private float AutoBuyCurrentStock(string sector, float amountToInvest)
    {
        float currentPrice = stockMarketSimulator.GetCurrentPrice(sector);
        if (currentPrice <= 0) return 0;

        float sharesToBuy = amountToInvest / currentPrice;
        if (sharesToBuy > 0)
        {
            var tempInputField = new GameObject().AddComponent<TMP_InputField>();
            tempInputField.text = amountToInvest.ToString(); // ส่งจำนวนเงินที่จะลงทุน

            AutoBuyCurrentStockSet(tempInputField, sector);

            Destroy(tempInputField.gameObject);
        }
        return sharesToBuy;
    }

    public void AutoBuyCurrentStockSet(TMP_InputField inputfield , string sector)
    {
        string inputText = inputfield.text;
        if (string.IsNullOrEmpty(sector) || !float.TryParse(inputText, out float cashToSpend)) return;

        float stockPrice = stockMarketSimulator.GetCurrentPrice(sector);
        float sharesToBuy = cashToSpend / stockPrice;
        Debug.Log(PlayerPortfolio.cash);
        Debug.Log(cashToSpend);
        Debug.Log(sharesToBuy);

        if (PlayerPortfolio.cash >= cashToSpend && sharesToBuy > 0)
        {
            Debug.Log(cashToSpend + "________________________________" + AllInvestment);
            AllCashandInvestmentHistory.Add(AllInvestment);

            playerPortfolio.SetPrinciple(playerPortfolio.Getprinciple() + cashToSpend);
            

            
            PlayerPortfolio.cash -= cashToSpend;

            if (!stockMarketSimulator.investments.ContainsKey(sector))
            {
                stockMarketSimulator.investments.Add(sector, new StockInvestment(sector));
            }

            StockInvestment investment = stockMarketSimulator.investments[sector];
            investment.shares += sharesToBuy;
            investment.totalInvestment += cashToSpend;

            playerPortfolio.UpdateCashUI();
            playerPortfolio.UpdatePortfolioUI();
        }
        else
        {
            Debug.Log("Not enough cash to buy shares or invalid amount.");
        }
    }


    public void OnButtonClicked(string sector)
    {
        currentDisplayedSector = sector;
        DisplayGraphForSector(sector);
    }



    // Helper methods for accessing historical data
    public List<Dictionary<string, float>> GetHistoricalPrices()
    {
        return historicalPrices;
    }

    public Dictionary<string, float> GetCurrentPrices()
    {
        return new Dictionary<string, float>(stockPrices);
    }

    public float GetPriceForSector(string sector)
    {
        return stockPrices.ContainsKey(sector) ? stockPrices[sector] : 0f;
    }

    public List<float> GetHistoricalPricesForSector(string sector)
    {
        var prices = new List<float>();
        foreach (var historicalSnapshot in historicalPrices)
        {
            if (historicalSnapshot.ContainsKey(sector))
            {
                prices.Add(historicalSnapshot[sector]);
            }
        }
        return prices;
    }

    public void DisplayGraphForTotalInvestment()
    {
        if (windowGraph == null)
        {
            Debug.LogError("Window_Graph reference is missing!");
            return;
        }

        // Clear previous graph data
        windowGraph.ClearGraph();

        List<int> investmentHistory = AllCashandInvestmentHistory.ConvertAll(value => (int)value); // Convert to int for compatibility
        if (investmentHistory.Count > 0)
        {
            windowGraph.ShowGraph(investmentHistory, maxVisibleValueAmount: investmentHistory.Count,
                getAxisLabelX: (i) => $"{i + 1}", getAxisLabelY: (value) => $"{value}");
        }
    }
}