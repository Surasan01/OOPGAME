using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class EndScene : GameData
{
    [Header("UI References")]
    [SerializeField] private Transform scoreboardContent;
    [SerializeField] private GameObject scoreEntryPrefab;
    public Button StartGame;
    public StartGameScene startGameScene;

    private void Start()
    {
        // บันทึกผลลัพธ์ของเกมปัจจุบัน
        if (StockPriceUpdater.percentOfTotal != 0)
        {
            AddGameResult(StockPriceUpdater.percentOfTotal);
        }

        StartGameScene startGameScene = new StartGameScene();
        StartGame.onClick.AddListener(() => startGameScene.NextScene());
        DisplayAllResults();
    }

    

    private void DisplayAllResults()
    {
        // ล้างข้อมูลเก่า
        foreach (Transform child in scoreboardContent)
        {
            Destroy(child.gameObject);
        }

        // แสดงประวัติทั้งหมด
        List<float> allResults = GetAllGameResults();
        for (int i = 0; i < allResults.Count; i++)
        {
            GameObject scoreEntry = Instantiate(scoreEntryPrefab, scoreboardContent);
            if (scoreEntry.GetComponentInChildren<TMP_Text>() is TMP_Text roundText)
            {
                roundText.text = $"การเล่นครั้งที่ {i + 1}    ผลการเจริญเติบโตทางเงินเป็น : {allResults[i]:F2}%";
                Debug.Log($"การเล่นครั้งที่ {i + 1}    ผลการเจริญเติบโตทางเงินเป็น : {allResults[i]:F2}%");
            }
        }
    }

    public void RestartGame()
    {
        SaveToPlayerPrefs();
        SceneManager.LoadScene("StartScene");
    }

    public void ClearResults()
    {
        ResetGameData();
        DisplayAllResults();
    }

    public override void BuyCurrentStock(TMP_InputField input)
    {
        // ไม่ทำอะไร
    }

    public override void SellCurrentStock(TMP_InputField input)
    {
        // ไม่ทำอะไร
    }
}