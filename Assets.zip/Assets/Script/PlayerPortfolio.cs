using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerPortfolio : GameData
{
    public StockMarketSimulator stockMarketSimulator;
    public TMP_Text sharesHeldText; // แสดงจำนวนหุ้นที่ถืออยู่ใน sector ปัจจุบัน
    public TMP_InputField cashInputFieldBuy; // ใช้ระบุจำนวนเงินที่ต้องการซื้อ
    public TMP_InputField cashInputFieldSell; // ใช้ระบุจำนวนเงินที่ต้องการขาย
    public TMP_Text cashText; // แสดงยอดเงินสดที่มีอยู่
    public Button buyButton;
    public Button sellButton;

    public TMP_Text AllInvestmentText;
    public TMP_Text ReceivedRoundText;
    public TMP_Text ReturnYearText;
    public TMP_Text PercentOfTotalText;
    public TMP_Text TotalReturnsText;

    private string currentSector;
    public static float cash;

    private float principle = 0;

    public static Dictionary<string, float> Setprinciple = new Dictionary<string, float>();

    public static float percentOfTotal = 0;

    void Start()
    {
        Setprinciple.Clear();

        List<string> sectors = new List<string> { "Technology", "Healthcare", "Financials", "Consumer Electronics", "Energy", "Entertainment" };

        foreach (string sector in sectors)
        {
            Setprinciple[sector] = 0; // ใช้ indexer แทนการใช้ Add
        }

        cash = PlayerPrefs.GetFloat("InitialCash", 0); // โหลดจำนวนเงินสดเริ่มต้นจาก PlayerPrefs
        UpdateCashUI();

        buyButton.onClick.AddListener(() => BuyCurrentStock(cashInputFieldBuy));
        sellButton.onClick.AddListener(() => SellCurrentStock(cashInputFieldSell));
    }

    public void SetCurrentSector(string sector)
    {
        currentSector = sector;
        UpdatePortfolioUI();
    }

    // เพิ่มฟังก์ชัน OnDestroy เพื่อทำความสะอาดข้อมูล static เมื่อ GameObject ถูกทำลาย
    void OnDestroy()
    {
        Setprinciple.Clear();
        cash = 0;
        percentOfTotal = 0;
    }

    public override void BuyCurrentStock(TMP_InputField inputfield)
    {
        string inputText = inputfield.text;
        if (string.IsNullOrEmpty(currentSector) || !float.TryParse(inputText, out float cashToSpend)) return;

        float stockPrice = stockMarketSimulator.GetCurrentPrice(currentSector);
        float sharesToBuy = cashToSpend / stockPrice;

        if (cash >= cashToSpend && sharesToBuy > 0)
        {
            StockPriceUpdater.AllInvestment += cashToSpend;
            

            principle += cashToSpend;
            StockPriceUpdater.totalReturn = StockPriceUpdater.AllInvestment - principle;

            percentOfTotal = ((StockPriceUpdater.AllInvestment / principle) * 100) - 100;

            TotalReturnsText.text = $"{StockPriceUpdater.totalReturn:F2}";
            AllInvestmentText.text = $"{StockPriceUpdater.AllInvestment:F2}";
            PercentOfTotalText.text = $"{percentOfTotal:F2}%";

            cash -= cashToSpend;

            if (!stockMarketSimulator.investments.ContainsKey(currentSector))
            {
                stockMarketSimulator.investments.Add(currentSector, new StockInvestment(currentSector));
            }

            StockInvestment investment = stockMarketSimulator.investments[currentSector];
            investment.shares += sharesToBuy;
            investment.totalInvestment += cashToSpend;

            // Update the Setprinciple dictionary
            if (Setprinciple.ContainsKey(currentSector)) // ถ้ามี sector นี้ใน dictionary และมีการซื้อหุ้น
            {
                Setprinciple[currentSector] += cashToSpend; // เพิ่มหลักทุนใน sector นี้
            }

            UpdateCashUI();
            UpdatePortfolioUI();
        }
        else
        {
            Debug.Log("Not enough cash to buy shares or invalid amount.");
        }
    }

    public override void SellCurrentStock(TMP_InputField inputfield)
    {
        string inputText = inputfield.text;
        if (string.IsNullOrEmpty(currentSector) || !float.TryParse(inputText, out float cashToEarn)) return;

        if (stockMarketSimulator.investments.ContainsKey(currentSector))
        {
            StockInvestment investment = stockMarketSimulator.investments[currentSector];
            float stockPrice = stockMarketSimulator.GetCurrentPrice(currentSector);
            float sharesToSell = cashToEarn / stockPrice;

            if (investment.shares >= sharesToSell && sharesToSell > 0)
            {
                StockPriceUpdater.AllInvestment -= cashToEarn;
                

                principle -= cashToEarn;
                StockPriceUpdater.totalReturn = StockPriceUpdater.AllInvestment - principle;

                percentOfTotal = ((StockPriceUpdater.AllInvestment / principle) * 100) - 100;

                TotalReturnsText.text = $"{StockPriceUpdater.totalReturn:F2}";
                AllInvestmentText.text = $"{StockPriceUpdater.AllInvestment:F2}";
                PercentOfTotalText.text = $"{percentOfTotal:F2}%";

                cash += sharesToSell * stockPrice;
                investment.shares -= sharesToSell;
                investment.totalInvestment -= sharesToSell * stockPrice;

                // Update the Setprinciple dictionary
                if (Setprinciple.ContainsKey(currentSector)) // ถ้ามี sector นี้ใน dictionary และมีการขายหุ้น
                {
                    Setprinciple[currentSector] -= cashToEarn; // ลดหลักทุนใน sector นี้
                }

                UpdateCashUI();
                UpdatePortfolioUI();
            }
            else
            {
                Debug.Log("Not enough shares to sell or invalid amount.");
            }
        }
        else
        {
            Debug.Log("You do not own any shares in this sector.");
        }
    }

    public void UpdateCashUI()
    {
        cashText.text = $"{cash:F2}";
    }

    public void UpdatePortfolioUI()
    {
        if (string.IsNullOrEmpty(currentSector))
        {
            sharesHeldText.text = "No sector selected.";
            return;
        }

        if (stockMarketSimulator.investments.ContainsKey(currentSector))
        {
            sharesHeldText.text = $"จำนวนหุ้นที่มี : {stockMarketSimulator.investments[currentSector].shares}";
        }
        else
        {
            sharesHeldText.text = "จำนวนหุ้นที่มี : 0";
        }
    }

    public float Getprinciple()
    {
        return principle;
    }

    public float SetPrinciple(float setprinciple)
    {
        return principle = setprinciple;
    }

}
