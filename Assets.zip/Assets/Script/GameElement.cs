using UnityEngine;

public abstract class GameElement : MonoBehaviour
{
    public abstract void InitializeElement();
}