﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Dice : GameElement
{
    private Sprite[] diceSides;
    private SpriteRenderer rend;
    public Button rollButton;
    private bool isRolling = false;

    // สร้าง Event เพื่อแจ้งเมื่อทอยลูกเต๋าเสร็จ
    public delegate void DiceRolledEventHandler(int result);
    public event DiceRolledEventHandler OnDiceRolled;

    private void Start()
    {
        InitializeElement();
    }

    public override void InitializeElement()
    {
        rend = GetComponent<SpriteRenderer>();
        diceSides = Resources.LoadAll<Sprite>("DiceSides/");
        rollButton.onClick.AddListener(OnRollButtonClicked);
    }

    private void OnRollButtonClicked()
    {
        if (!isRolling)
        {
            StartCoroutine(RollTheDice());
        }
    }

    private IEnumerator RollTheDice()
    {
        isRolling = true;
        int finalSide = 0;

        for (int i = 0; i <= 20; i++)
        {
            int randomDiceSide = Random.Range(0, diceSides.Length);
            rend.sprite = diceSides[randomDiceSide];
            yield return new WaitForSeconds(0.05f);
        }

        finalSide = Random.Range(1, 7);
        rend.sprite = diceSides[finalSide - 1];

        // Trigger event to notify other classes
        OnDiceRolled?.Invoke(finalSide);

        isRolling = false;
    }
}
