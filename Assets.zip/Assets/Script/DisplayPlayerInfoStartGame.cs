using TMPro;
using UnityEngine;

public class DisplayPlayerInfoStartGame : MonoBehaviour
{
    public TMP_Text NameText;
    public TMP_Text CashText;
    public TMP_Text AgeText;
    public TMP_Text EndAgeText;
    public TMP_Text PointPerMonthText;

    private int monthsPerPoint;

    private int age;
    private int endAge;

    void Start()
    {
        // คือการดึงข้อมูลจาก PlayerPrefs มาใช้งาน
        string playerName = GameData.GetPlayerName();
        float InitialCash = GameData.GetInitialCash();
        age = GameData.GetAge();
        endAge = GameData.GetEndAge();

        // คำนวณเดือนต่อแต้ม
        if (endAge > age)
        {
            monthsPerPoint = Mathf.CeilToInt((float)(endAge - age) * 12 / 100);
        }
        else
        {
            Debug.LogError("End age should be greater than start age");
            monthsPerPoint = 1; 
        }

        // แสดงข้อมูลผู้เล่น
        NameText.text = $"{playerName}";
        AgeText.text = $"{age} ปี";
        EndAgeText.text = $"{endAge} ปี";
        CashText.text = $"{InitialCash} บาท";
        PointPerMonthText.text = $"1 แต้ง ต่อ {monthsPerPoint} เดือน";

        // บันทึกข้อมูลเดือนต่อแต้มลง PlayerPrefs
        PlayerPrefs.SetInt("MonthsPerPoint", monthsPerPoint);
    }

    //  คือการดึงข้อมูลจาก PlayerPrefs มาใช้งาน
    public int GetMonthsPerPoint()
    {
        return monthsPerPoint;
    }  
}
