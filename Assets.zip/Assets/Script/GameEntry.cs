using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameEntry : MonoBehaviour
{
    public TMP_InputField NameInputField;
    public TMP_InputField MoneyInputField;
    public TMP_InputField AgeInputField;
    public TMP_InputField EndAgeInputField;
    public GameEntryScene GameEntryScene;

    private void Start()
    {
        // Reset game data when starting a new game
        GameData.ResetGameData();
    }

    public void StartGame()
    {
        // Save data to GameData
        GameData.SetPlayerName(NameInputField.text);
        GameData.SetInitialCash(float.Parse(MoneyInputField.text.Trim()));
        GameData.SetAge(int.Parse(AgeInputField.text.Trim()));
        GameData.SetEndAge(int.Parse(EndAgeInputField.text.Trim()));

        // Save to PlayerPrefs
        GameData.SaveToPlayerPrefs();

        GameEntryScene gameEntryScene = new GameEntryScene();
        gameEntryScene.NextScene();
    }

    private bool ValidateInputs()
    {
        return !string.IsNullOrEmpty(NameInputField.text) &&
               float.TryParse(MoneyInputField.text.Trim(), out _) &&
               int.TryParse(AgeInputField.text.Trim(), out _) &&
               int.TryParse(EndAgeInputField.text.Trim(), out _);
    }
}
