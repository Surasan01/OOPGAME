using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CharacterLoopMovement : MonoBehaviour
{

    [Header("ตั้งค่าการเคลื่อนที่สำหรับ Character")]
    [SerializeField] private float moveSpeedCharacter = 100;
    [SerializeField] private Vector3 startPositionCharacter;
    [SerializeField] private Vector3 endPositionCharacter;
    private Vector3 currentVelocityCharacter = Vector3.zero;
    private Vector3 targetPositionCharacter;
    private bool isMovingCharacter = false;

    [Header("ตั้งค่าการเคลื่อนที่สำหรับ Age Indicator")]
    [SerializeField] private float moveSpeedAgeIndicator = 1;
    [SerializeField] private Vector3 startPositionAgeIndicator;
    [SerializeField] private Vector3 endPositionAgeIndicator;
    private Vector3 currentVelocityAgeIndicator = Vector3.zero;
    private Vector3 targetPositionAgeIndicator;
    private bool isMovingAgeIndicator = false;

    [Header("ตั้งค่าอายุ")]
    [SerializeField] private int startAge;  // อายุเริ่มต้น
    [SerializeField] private int endAge;    // อายุสิ้นสุด
    private int totalMonths;                     // จำนวนเดือนทั้งหมด
    private float moveDistancePerMonth;          // ระยะทางต่อเดือน

    [Header("การอ้างอิงคอมโพเนนต์")]
    [SerializeField] private Image characterImage;
    [SerializeField] private Image standcharacterImage;
    [SerializeField] private Image walkcharacterImage;
    [SerializeField] private Image ageIndicatorImage;
    [SerializeField] private TMP_Text ageText;  // สำหรับแสดงอายุปัจจุบัน

    StockPriceUpdater stockPriceUpdater;

    private void Start()
    {
        stockPriceUpdater = FindObjectOfType<StockPriceUpdater>();
        if (stockPriceUpdater == null)
        {
            Debug.LogError("StockPriceUpdater component not found in the scene.");
            return;
        }

        startAge = GameData.GetAge();
        endAge = GameData.GetEndAge();

        Debug.Log($"Start Age: {startAge}");
        Debug.Log($"End Age: {endAge}");

        InitializeAgeMovement();
        InitializeCharacterMovement();
    }

    private void InitializeAgeMovement()
    {
        totalMonths = (endAge - startAge) * 12; // คำนวณจำนวนเดือนทั้งหมด
        // คำนวณระยะทางที่ต้องเคลื่อนที่ต่อเดือน
        float totalDistance = Vector3.Distance(
            startPositionAgeIndicator,
            endPositionAgeIndicator
        );
        moveDistancePerMonth = totalDistance / totalMonths;
        Debug.Log($"Total months: {totalMonths}, Move distance per month: {moveDistancePerMonth}");

        ageIndicatorImage.transform.position = startPositionAgeIndicator;
        UpdateAgeDisplay();
    }

    private void InitializeCharacterMovement()
    {
        characterImage.transform.position = startPositionCharacter;
        targetPositionCharacter = endPositionCharacter;
    }

    private void Update()
    {
        if (isMovingCharacter)
        {
            UpdateCharacterMovement();
        }
        if (isMovingAgeIndicator)
        {
            UpdateAgeIndicatorMovement();
        }
    }

    public void UpdateCharacterMovement()
    {
        Vector3 newPosition = Vector3.MoveTowards(
            characterImage.transform.position,
            targetPositionCharacter,
            moveSpeedCharacter * Time.deltaTime
        );

        characterImage.transform.position = newPosition;

        if (Vector3.Distance(characterImage.transform.position, targetPositionCharacter) < 0.1f)
        {
            characterImage.transform.position = startPositionCharacter;
        }
    }

    public void UpdateAgeIndicatorMovement()
    {
        if (stockPriceUpdater.currentMonth >= totalMonths)
        {
            StopAgeIndicatorMovement();
            return;
        }

        // คำนวณตำแหน่งเป้าหมายสำหรับเดือนปัจจุบัน
        float targetY = startPositionAgeIndicator.y - (moveDistancePerMonth * stockPriceUpdater.currentMonth);
        

        Vector3 targetPosition = new Vector3(startPositionAgeIndicator.x, targetY, startPositionAgeIndicator.z);

        Vector3 newPosition = Vector3.MoveTowards(
            ageIndicatorImage.transform.position,
            targetPosition,
            moveSpeedAgeIndicator * Time.deltaTime
        );

        ageIndicatorImage.transform.position = newPosition;

        UpdateAgeDisplay();
    }

    private void UpdateAgeDisplay()
    {
        if (ageText != null)
        {
            float currentAge = startAge + (stockPriceUpdater.currentMonth / 12f);
            ageText.text = $"{currentAge:F1} ปี";
        }
    }

    public void StartCharacterMovement()
    {
        // ซ่อนภาพท่ายืนและแสดงภาพท่าเดินเมื่อเริ่มเคลื่อนที่
        standcharacterImage.enabled = false;
        walkcharacterImage.enabled = true;

        isMovingCharacter = true;
        targetPositionCharacter = endPositionCharacter;
    }

    public void StartAgeIndicatorMovement()
    {
        if (stockPriceUpdater.currentMonth >= totalMonths) return;
        isMovingAgeIndicator = true;
    }

    public void StopCharacterMovement()
    {
        // ซ่อนภาพท่าเดินและแสดงภาพท่ายืนเมื่อหยุดเคลื่อนที่
        standcharacterImage.enabled = true;
        walkcharacterImage.enabled = false;

        isMovingCharacter = false;
        currentVelocityCharacter = Vector3.zero;
    }

    public void StopAgeIndicatorMovement()
    {
        isMovingAgeIndicator = false;
        currentVelocityAgeIndicator = Vector3.zero;
    }

    public void ResetAgeMovement()
    {
        stockPriceUpdater.currentMonth = 0;
        ageIndicatorImage.transform.position = startPositionAgeIndicator;
        UpdateAgeDisplay();
    }
}
