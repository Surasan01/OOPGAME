using System.Collections.Generic;
using TMPro;
using UnityEngine;

public abstract class GameData : MonoBehaviour
{
    private static string PlayerName;
    private static float InitialCash;
    private static int Age;
    private static int EndAge;

    // คือการสร้าง List ของผลลัพธ์เกมที่เล่น
    private static List<float> gameResults = new List<float>();

    public static void ResetGameData()
    {
        PlayerName = "";
        InitialCash = 0;
        Age = 0;
        EndAge = 0;
        PlayerPrefs.DeleteAll();
    }

    public static void SaveToPlayerPrefs()
    {
        PlayerPrefs.SetString("PlayerName", PlayerName);
        PlayerPrefs.SetFloat("InitialCash", InitialCash);
        PlayerPrefs.SetInt("Age", Age);
        PlayerPrefs.SetInt("EndAge", EndAge);

        // บันทึกผลลัพธ์เกมที่เล่นล่าสุด
        PlayerPrefs.SetInt("TotalGames", gameResults.Count);
        for (int i = 0; i < gameResults.Count; i++)
        {
            PlayerPrefs.SetFloat($"Game_{i}_Result", gameResults[i]);
        }
        PlayerPrefs.Save();
    }

    public static void LoadFromPlayerPrefs()
    {
        PlayerName = PlayerPrefs.GetString("PlayerName", "");
        InitialCash = PlayerPrefs.GetFloat("InitialCash", 0);
        Age = PlayerPrefs.GetInt("Age", 0);
        EndAge = PlayerPrefs.GetInt("EndAge", 0);

        // โหลดผลลัพธ์เกมที่เล่นล่าสุด
        gameResults.Clear();
        int totalGames = PlayerPrefs.GetInt("TotalGames", 0);
        for (int i = 0; i < totalGames; i++)
        {
            float result = PlayerPrefs.GetFloat($"Game_{i}_Result", 0f);
            gameResults.Add(result);
        }
    }

    // คึนค่าผลลัพธ์เกมที่เล่นล่าสุด
    public static void AddGameResult(float percentage)
    {
        gameResults.Add(percentage);
        SaveToPlayerPrefs();
    }

    // คืนค่า List ของผลลัพธ์ทั้งหมด
    public static List<float> GetAllGameResults()
    {
        return new List<float>(gameResults);
    }

    public abstract void BuyCurrentStock(TMP_InputField input);

    public abstract void SellCurrentStock(TMP_InputField input);


    public static string GetPlayerName()
    {
        return PlayerName;
    }

    public static string SetPlayerName(string name)
    {
        return PlayerName = name;
    }

    public static float GetInitialCash()
    {
        return InitialCash;
    }

    public static float SetInitialCash(float cash)
    {
        return InitialCash = cash;
    }

    public static int GetAge()
    {
        return Age;
    }

    public static int SetAge(int age)
    {
        return Age = age;
    }

    public static int GetEndAge()
    {
        return EndAge;
    }

    public static int SetEndAge(int endAge)
    {
        return EndAge = endAge;
    }

    
}