using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGameScene : Scenes
{
    public override void NextScene()
    {
        SceneManager.LoadScene("StartScene");
    }
}
