package com.example.financegame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancegameApplicationTests {

	@Test
	void contextLoads() {
	}

}
