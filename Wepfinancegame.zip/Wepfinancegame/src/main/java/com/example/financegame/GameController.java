package com.example.financegame;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

@RestController
@RequestMapping("/api")
public class GameController {

    @PostMapping("/startGame")
    public Response startGame() {
        // Log เมื่อเริ่มเกม
        System.out.println("เกมเริ่มแล้ว!");

        // ส่งผลตอบกลับไปยังหน้าเว็บ
        return new Response("เกมเริ่มต้นเรียบร้อยแล้ว!");
    }

    @GetMapping("/game")
    public RedirectView loadGame() {
        // Redirect ไปยังตัวเกม WebGL (index.html ที่ Unity สร้าง)
        return new RedirectView("/webgl/index.html");
    }
}

// คลาสสำหรับผลตอบกลับ
class Response {
    private String message;

    public Response(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
