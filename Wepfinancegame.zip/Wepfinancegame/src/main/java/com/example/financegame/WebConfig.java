package com.example.financegame;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/webgl/**")
                .addResourceLocations("classpath:/static/webgl/")
                .setCachePeriod(3600)
                .resourceChain(true)
                .addTransformer((request, resource, transformerChain) -> {
                    if (resource.getFilename().endsWith(".gz")) {
                        // Cast the request to ServletWebRequest to access response
                        ((ServletWebRequest) request).getResponse()
                            .addHeader("Content-Encoding", "gzip");
                    }
                    return transformerChain.transform(request, resource);
                });
    }
}
