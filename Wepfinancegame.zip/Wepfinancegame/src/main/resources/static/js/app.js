document.getElementById("playButton").addEventListener("click", function () {
    // ส่งคำสั่ง POST ไปที่ API /api/startGame
    fetch("/api/startGame", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        // แสดงข้อความตอบกลับ
        document.getElementById("message").textContent = data.message;

        // หลังจากเริ่มเกมแล้ว Redirect ไปที่ WebGL ตัวเกม
        setTimeout(() => {
            window.location.href = "/api/game";
        }, 1000); // หน่วงเวลา 1 วินาทีก่อน Redirect
    })
    .catch(error => {
        console.error("Error:", error);
        document.getElementById("message").textContent = "เกิดข้อผิดพลาด!";
    });
});
